from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.views import View
from main_page.models import Profile
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import connection
from django.db import transaction

from main_page.models import Profile
from .models import Product, RecycleHistory


class Recycle(View):
    template_name = 'recycle/all.html'

    def get(self, request):
        products = Product.objects.all()
        return render(request, self.template_name, {'products': products})


@method_decorator(login_required, name='dispatch')
class ProductDetails(View):
    template_name = 'recycle/details.html'

    def get(self, request, pk):
        # product = Product.objects.get(pk=pk)
        product = Product.objects.raw("SELECT * FROM RECYCLE_PRODUCT WHERE ID={id}".format(id=pk))[0]
        return render(request, self.template_name, {'product': product})

    def post(self, request, pk):
        quantity = int(request.POST.get('quantity'))
        user = request.user
        profile = Profile.objects.get(pk=user.id)
        product = Product.objects.get(pk=pk)
        product.quantity += quantity
        product.save()

        payments = quantity * product.payment
        profile.balance += payments
        profile.save()
        id_out = None
        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            return_stuff = cursor.callproc('RECYCLE_HISTORY.CREATE_HISTORY', [
                user.id,
                product.id,
                quantity,
                id_out])

        # recycle_history = RecycleHistory.objects.create(
        #     user_id=user.id, product_id=product.id, quantity=quantity)

        return redirect(reverse('recycle:history', args=(int(return_stuff[-1]),)))


@method_decorator(login_required, name='dispatch')
class History(View):
    template_name = 'recycle/history.html'

    def get(self, request, pk):
        cursor = connection.cursor()
        cursor.execute('SELECT "USER_ID",\
                            "USERNAME",\
                            "PRODUCT_ID",\
                            "PRODUCT_NAME",\
                            "CREATE_TIME",\
                            "HISTORY_QUANTITY" \
            FROM "RECYCLE_RECYCLEHISTORY_VIEW" \
            WHERE "HISTORY_ID" = {id}'.format(id=pk))

        USER_ID, USERNAME, PRODUCT_ID, PRODUCT_NAME, \
            CREATE_TIME, HISTORY_QUANTITY = cursor.fetchone()
        
        context = {
            "USER_ID": USER_ID,
            "USERNAME": USERNAME,
            "PRODUCT_ID": PRODUCT_ID,
            "PRODUCT_NAME": PRODUCT_NAME,
            "CREATE_TIME": CREATE_TIME,
            "HISTORY_QUANTITY": HISTORY_QUANTITY
        }
        # history = RecycleHistory.objects.get(pk=pk)
        return render(request, self.template_name, context)


@method_decorator(login_required, name='dispatch')
class ViewProfile(View):
    template_name = 'recycle/view_profile.html'

    def get(self, request, pk=None):
        if not pk:
            pk = request.user.id

        profile = Profile.objects.get(pk=pk)
        history = RecycleHistory.objects.filter(user_id=pk)
        return render(request, self.template_name, {'profile': profile, 'history': history})
