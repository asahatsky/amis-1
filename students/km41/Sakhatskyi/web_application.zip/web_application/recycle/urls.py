from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth

urlpatterns = [

    url(r'^all/$', views.Recycle.as_view(), name='recycle'),

    url(r'^product/details/(?P<pk>\d+)/$', views.ProductDetails.as_view(), name='details'),

    url(r'^history/(?P<pk>\d+)/$', views.History.as_view(), name='history'),

    # url(r'^orders/(?P<pk>\d+)/$', views.Orders.as_view(), name='orders_pk'),

    # url(r'^user_order/$', views.UserOrders.as_view(), name='user'),
    # url(r'^user_order/(?P<pk>\d+)/$', views.UserOrders.as_view(), name='user_pk'),

    url(r'^profile/$', views.ViewProfile.as_view(), name='my_profile'),
    url(r'^profile/(?P<pk>\d+)/$', views.ViewProfile.as_view(), name='other_profile'),

    # url(r'^order_details/(?P<pk>\d+)/$', views.OrderDetails.as_view(), name='order_details'),

]
