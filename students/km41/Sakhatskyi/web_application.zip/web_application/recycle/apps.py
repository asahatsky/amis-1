from django.apps import AppConfig


class RecycleConfig(AppConfig):
    name = 'recycle'
