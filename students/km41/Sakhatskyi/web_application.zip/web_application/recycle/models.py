from django.db import models
from django.conf import settings

CHOISE_BIN = (('Green', 'Green'), ('Red', 'Red'), ('Blue', 'Blue'))


class Material(models.Model):
    name = models.CharField(
        max_length=35,
        default='Meterial name'
    )
    description = models.CharField(
        max_length=200,
        default='Meterial description'
    )
    recycle_bin_type = models.CharField(
        max_length=10,
        choices=CHOISE_BIN, default='Green'
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Material"
        verbose_name_plural = "Materials"


class Product(models.Model):
    name = models.CharField(
        max_length=35,
        default='Default name',
    )
    description = models.CharField(
        max_length=200,
        blank=True,
        null=True,
    )
    material = models.ForeignKey(
        'Material',
        verbose_name='Material',
        on_delete=models.SET_NULL,
        null=True,
    )
    payment = models.PositiveIntegerField(
        default=0,
    )
    quantity = models.PositiveIntegerField(
        default=0,
    )
    product_image = models.ImageField(
        upload_to='product_image/',
        blank=True,
        default='product_image/product_image.jpg',
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Product"
        verbose_name_plural = "Products"


class RecycleHistory(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name='User',
        on_delete=models.SET_NULL,
        null=True,
    )
    product = models.ForeignKey(
        'Product',
        verbose_name='Product',
        on_delete=models.SET_NULL,
        null=True,
    )
    quantity = models.PositiveIntegerField(
        default=0,
    )
    create_time = models.DateTimeField(
        'Created',
        auto_now_add=True,
        null=True,
    )

    def __str__(self):
        return '{} on {}'.format(self.product.name, self.create_time)

    class Meta:
        verbose_name = "Recycle history"
        verbose_name_plural = "Recycle histories"
