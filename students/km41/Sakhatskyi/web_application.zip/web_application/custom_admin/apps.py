from django.apps import AppConfig


class CustomAdminConfig(AppConfig):
    name = 'custom_admin'
