from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.views import View
from recycle.models import Product
from .forms import ProductForm
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import connection
from django.db import transaction
from django.core.files.storage import FileSystemStorage


def get_query_params(request):
    name = request.POST.get('name')
    description = request.POST.get('description') or ''
    material = int(request.POST.get('material'))
    payment = int(request.POST.get('payment'))
    quantity = int(request.POST.get('quantity'))
    product_image = request.FILES.get('product_image')
    # import ipdb; ipdb.set_trace()
    if not product_image:
        product_image = 'product_image/product_image.jpg'
    else:
        product_image = 'product_image/' + product_image.name
        photo = request.FILES.get('product_image')
        fs = FileSystemStorage()
        filename = fs.save(product_image, photo)
    return name, description, material, payment, quantity, product_image

@method_decorator(login_required, name='dispatch')
class AdminPage(View):
    template_name = 'custom_admin/admin.html'

    def get(self, request):
        products = Product.objects.all()
        form = ProductForm()
        return render(request, self.template_name, {'form': form, 'products': products})

    def post(self, request):
        form = ProductForm(request.POST, request.FILES)

        if form.is_valid():
            name, description, material, payment, quantity, product_image = get_query_params(request)
            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('PRODUCT_OPERATIONS.CREATE_P', [
                    name,
                    description,
                    payment,
                    quantity,
                    product_image,
                    material])

            # form.save()
            return redirect(reverse('custom_admin:main'))
        return render(request, self.template_name, {'form':form})


@method_decorator(login_required, name='dispatch')
class DeleteProduct(View):

    def post(self, request, pk):
        # Product.objects.get(pk=pk).delete()
        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            cursor.callproc('PRODUCT_OPERATIONS.DELETE_P', [pk])
        return redirect(reverse('custom_admin:main'))


@method_decorator(login_required, name='dispatch')
class EditProduct(View):
    template_name = 'custom_admin/edit.html'

    def get(self, request, pk):
        product = Product.objects.get(pk=pk)
        form = ProductForm(instance=product)
        return render(request, self.template_name, {'form': form, 'product': product})

    def post(self, request, pk):
        product = Product.objects.get(pk=pk)
        form = ProductForm(request.POST, request.FILES, instance=product)

        if form.is_valid():
            name, description, material, payment, quantity, product_image = get_query_params(request)

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('PRODUCT_OPERATIONS.UPDATE_P', [
                    pk,
                    name,
                    description,
                    payment,
                    quantity,
                    product_image,
                    material])
            # form.save()
            return redirect(reverse('custom_admin:main'))
        return render(request, self.template_name, {'form':form})
