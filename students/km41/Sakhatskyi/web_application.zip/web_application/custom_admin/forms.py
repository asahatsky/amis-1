from recycle.models import Product, Material
from django import forms
from django.forms.widgets import PasswordInput, NumberInput

CHOISE_BIN = ((1, 'Green'), (2, 'Red'), (3, 'Blue'))

class ProductForm(forms.ModelForm):
    name = forms.CharField(max_length=50)
    description = forms.CharField(max_length=50, required=False)
    material = forms.ModelChoiceField(queryset=Material.objects.all())
    payment = forms.IntegerField(required=True, widget=NumberInput(attrs={'class':'validate', 'min':"1", 'max': "100"}))
    quantity = forms.IntegerField(widget=NumberInput(attrs={'class':'validate', 'min':"0", 'max': "1000"}))
    product_image = forms.ImageField(required=False)

    class Meta:
        model = Product
        fields = '__all__'
