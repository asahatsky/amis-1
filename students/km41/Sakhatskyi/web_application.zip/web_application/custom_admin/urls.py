from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth

urlpatterns = [

    url(r'^$', views.AdminPage.as_view(), name='main'),

    url(r'^delete_product/(?P<pk>\d+)/$', views.DeleteProduct.as_view(), name='delete_product'),

    url(r'^edit/(?P<pk>\d+)/$', views.EditProduct.as_view(), name='edit_product'),

]
