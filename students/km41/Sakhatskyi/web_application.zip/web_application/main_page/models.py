from django.db import models
from django.contrib.auth.models import AbstractUser


class Profile(AbstractUser):
    image = models.ImageField(upload_to='images/',blank=True,default='images/no_profile.png',verbose_name='File')
    balance = models.PositiveIntegerField(
        null=True,
        blank=True,
        default=0,
    )

    class Meta(object):
        unique_together = ('email',)
