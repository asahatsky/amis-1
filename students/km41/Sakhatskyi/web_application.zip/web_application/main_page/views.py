from django.shortcuts import render, redirect
from .forms import ProfileForm
from django.core.urlresolvers import reverse
from django.contrib.auth import login, authenticate

def signup(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()

            return redirect('/login/')
    else:
        form = ProfileForm()
    return render(request, 'signup.html', {'form': form})


def home(request):
	return render(request, 'home.html')
