from django import forms
from django.contrib.auth.forms import UserCreationForm

# from .models import Taxi
from .models import Profile

from django.forms.widgets import PasswordInput, TextInput


class ProfileForm(UserCreationForm):
    username = forms.CharField(max_length=40, help_text='Username')
    first_name = forms.CharField(max_length=40, required=False, help_text='Optional')
    last_name = forms.CharField(max_length=40, required=False, help_text='Optional')
    email = forms.EmailField(max_length=40, help_text='Required',
        widget=TextInput(attrs={'class':'validate','placeholder': 'my_email@mail.com', 'pattern':"[A-Za-z0-9._]+@[A-Za-z0-9._]+\.[A-Za-z]{2,5}", 'title': "my_email@mail.com"}))
    image = forms.ImageField(required=False, help_text='Optional')

    class Meta:
        model = Profile
        fields = ('username', 'first_name', 'last_name', 'email', 'password1',
            'password2', 'image',
            )

    def save(self, commit=True):
        user = super(ProfileForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.image = self.cleaned_data['image']

        user.save()

        return user
