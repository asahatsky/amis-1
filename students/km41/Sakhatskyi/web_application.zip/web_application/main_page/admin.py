from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DefaultUserAdmin

from .models import Profile


class UserAdmin(DefaultUserAdmin):
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Profile info', {'fields': ('username', 'first_name', 'last_name', 'email', 'image',
        	# 'phone', 'adress', 'shop_name',
        	'is_active', 'is_superuser', 'is_staff',)}),
    )    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'first_name', 'last_name', 'email', 'password1', 'password2', 'image',
            	# 'phone', 'adress', 'shop_name',
            	'is_active', 'is_superuser', 'is_staff')}
        ),
    )


admin.site.register(Profile, UserAdmin)
