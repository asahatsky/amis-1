from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth

urlpatterns = [

    url(r'^$', views.home, name='home'),

    url(r'^login/$', auth.login, {'template_name': 'login.html'}, name='login'),
    url(r'^signup/$', views.signup, name='signup'),

    url(r'^logout/$', auth.logout, {'next_page': '/login/'}, name='logout'),

]
